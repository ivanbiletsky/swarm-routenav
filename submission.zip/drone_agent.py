# OUR 4-way terrain-router: p003 (city/warehouse) | agent_village (OPEN specialist) |
# agent_onnx (forest + map label) | agent_pt (mountain/village). Obs-isolated + route-lock.
import os, sys, importlib.util
_DIR = os.path.dirname(os.path.abspath(__file__))
def _load(m, f):
    spec = importlib.util.spec_from_file_location(m, os.path.join(_DIR, f))
    mod = importlib.util.module_from_spec(spec); sys.modules[m] = mod
    spec.loader.exec_module(mod); return mod
_p003 = _load("_r_p003", "agent_p003.py")
_vil  = _load("_r_vil", "agent_village.py")
_onnx = _load("_r_onnx", "agent_onnx.py")
_pt   = _load("_r_pt", "agent_pt.py")
_LOCK_TICK = int(os.environ.get("LOCK_TICK", "150"))
def _cp(o):
    try: return {k:(v.copy() if hasattr(v,"copy") else v) for k,v in o.items()}
    except Exception: return o
class DroneFlightController:
    def __init__(self, **kw):
        self._a_p003=_p003.DroneFlightController(); self._a_vil=_vil.DroneFlightController()
        self._a_onnx=_onnx.DroneFlightController(); self._a_pt=_pt.DroneFlightController()
        self.reset()
    def reset(self):
        for a in (self._a_p003,self._a_vil,self._a_onnx,self._a_pt):
            if hasattr(a,"reset"):
                try: a.reset()
                except Exception: pass
        self._tick=0; self._locked=None
    def act(self, observation):
        self._tick += 1
        if self._locked is not None:
            return self._locked.act(observation)
        o0=_cp(observation); o1=_cp(observation); o2=_cp(observation); o3=_cp(observation)
        a_p003=self._a_p003.act(o0); a_vil=self._a_vil.act(o1)
        a_onnx=self._a_onnx.act(o2); a_pt=self._a_pt.act(o3)
        label = getattr(self._a_onnx, "_map_prediction_label", None)
        if label in ("mountain","village"): chosen,action=self._a_pt,a_pt
        elif label=="forest": chosen,action=self._a_onnx,a_onnx
        elif label=="open": chosen,action=self._a_vil,a_vil
        else: chosen,action=self._a_p003,a_p003
        if self._tick>=_LOCK_TICK and label is not None: self._locked=chosen
        return action
